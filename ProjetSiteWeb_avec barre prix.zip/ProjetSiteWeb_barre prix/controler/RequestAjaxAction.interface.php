<?php
interface RequestAjaxAction {
	//rien
}