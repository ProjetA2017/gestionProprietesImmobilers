<?php
require_once('./controler/Action.interface.php');
class LoginAction implements Action {
		public function execute(){
				require_once './model/classes/GereMembre.php';
				if (ISSET($_REQUEST["bConnexion"])) {   //demande de connexion
				//	if (GereMembre::connexion())
				GereMembre::connexion();
				return "accueil";
				//return "erreurs";
				}
		}
}
