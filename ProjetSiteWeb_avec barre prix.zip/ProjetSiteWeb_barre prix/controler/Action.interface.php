<?php
interface Action {
	public function execute();
}
?>