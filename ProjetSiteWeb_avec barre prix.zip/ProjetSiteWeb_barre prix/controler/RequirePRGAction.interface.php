<?php
interface RequirePRGAction {
//interface vide (interface de marquage ou tagging interface).
}
