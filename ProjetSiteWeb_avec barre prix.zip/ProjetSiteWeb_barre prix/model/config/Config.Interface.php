<?php
	interface Config
	{
		const URL = "localhost/gestionproprietes";
		const DB_HOST = "localhost";
		const DB_USER = "root";
		const DB_PWD = "root";
		const DB_NAME = "gestionproprietes";
	}
?>
